module.exports = {
  content: ["*", "./pages/*", "./js/*"],
  theme: {
    extend: {},
  },
  plugins: [],
};
